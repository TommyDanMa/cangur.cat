<?php

declare(strict_types=1);

return [
    'reset'     => 'La contrasenya s\'ha restablert!',
    'sent'      => 'Li hem enviat un correu electrònic amb un enllaç per a reiniciar la seva contrasenya!',
    'throttled' => 'Si us plau, esperi abans de tornar-ho a intentar.',
    'token'     => 'Aquest token de recuperació de contrasenya és invàlid.',
    'user'      => 'No existeix cap usuari amb aquest correu.',
];
