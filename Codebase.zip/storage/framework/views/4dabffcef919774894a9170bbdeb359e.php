<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['noSolution' =>false, 'solution' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['noSolution' =>false, 'solution' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($noSolution): ?>
    <span class="inline-flex items-center text-xs text-gray-700 bg-gray-100 rounded px-2 py-0.5">sense solució (0000)</span>
<?php elseif(!is_null($solution)): ?>
    <span class="inline-flex items-center text-xs text-indigo-700 bg-indigo-100 rounded px-2 py-0.5">#<?php echo e($solution); ?></span>
<?php else: ?>
    <span class="inline-flex items-center text-xs text-gray-600 bg-gray-100 rounded px-2 py-0.5">—</span>
<?php endif; ?>
<?php /**PATH /Users/Tom/PhpstormProjects/web-copa-canguro/resources/views/components/solution-badge.blade.php ENDPATH**/ ?>