<svg width="48" height="48" viewBox="0 0 96 84" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M38.3867 52.0625L35.8701 55.166L12.7891 84H0L25.5098 52.0713L0 20H12.7812L38.3867 52.0625ZM63.999 44.0244L83.2207 20H96L70.3887 52.0576L96 84H83.2236L64 60.0879L44.7773 84H32L57.6113 52.0557L32 20H44.7783L63.999 44.0244ZM89 10H39V0H89V10Z" fill="black"/>
</svg>
<?php /**PATH /Users/Tom/PhpstormProjects/web-copa-canguro/resources/views/components/application-logo.blade.php ENDPATH**/ ?>