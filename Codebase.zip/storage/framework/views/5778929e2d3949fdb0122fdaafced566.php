<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Problemes')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6 space-y-4">
                <form method="GET" action="<?php echo e(route('questions.index')); ?>" class="space-y-3">
                    <div class="flex flex-wrap items-end gap-3">
                        <div class="js-react-typeahead"
                             data-name="year"
                             data-endpoint="<?php echo e(url('/questions/suggest')); ?>"
                             data-field="year"
                             data-initial="<?php echo e(request('year')); ?>"
                             data-placeholder="Any"
                             data-width-class="w-40"></div>

                        <div class="js-react-typeahead"
                             data-name="level"
                             data-endpoint="<?php echo e(url('/questions/suggest')); ?>"
                             data-field="level"
                             data-initial="<?php echo e(request('level')); ?>"
                             data-placeholder="Nivell"
                             data-width-class="w-44"></div>

                        <div class="js-react-typeahead"
                             data-name="phase"
                             data-endpoint="<?php echo e(url('/questions/suggest')); ?>"
                             data-field="phase"
                             data-initial="<?php echo e(request('phase')); ?>"
                             data-placeholder="Fase"
                             data-width-class="w-44"></div>

                        <div class="js-react-typeahead"
                             data-name="session"
                             data-endpoint="<?php echo e(url('/questions/suggest')); ?>"
                             data-field="session"
                             data-initial="<?php echo e(request('session')); ?>"
                             data-placeholder="Sessió"
                             data-width-class="w-44"></div>

                        <button type="submit" class="px-4 h-10 bg-indigo-600 text-white rounded-md">Cerca</button>
                    </div>
                </form>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 'teacher'): ?>
                        <p><a href="<?php echo e(route('questions.create')); ?>"> + Nou problema</a></p>
                    <?php endif; ?>
                <?php endif; ?>

                <ul>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('questions.show',$q)); ?>"><?php echo e($q->title); ?>

                            (<?php echo e($q->year); ?> · <?php echo e($q->level); ?>)
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <?php echo e($questions->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/Tom/PhpstormProjects/web-copa-canguro/resources/views/questions/index.blade.php ENDPATH**/ ?>