<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e($question->title); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6 space-y-4">
                <p class="text-sm text-gray-600">
                    <strong>Any:</strong> <?php echo e($question->year); ?> · <strong>Nivell:</strong> <?php echo e($question->level); ?>

                </p>
                <p class="text-gray-800"><?php echo e($question->statement); ?></p>
                <?php if($question->image_path): ?>
                    <img src="<?php echo e(asset('storage/'.$question->image_path)); ?>" alt="Imatge del problema" class="rounded max-w-full h-auto">
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <div>
                        <a  href="<?php echo e(route('answers.create', $question)); ?>"
                            class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            ✍️ Enviar resposta
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mt-8">
                <h3 class="text-lg font-medium text-gray-900 mb-3"><?php echo e(__('Respostes')); ?></h3>
                <?php $__empty_1 = true; $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('answers.show', $answer)); ?>" class="block bg-white shadow-sm sm:rounded-lg p-4 mb-3 hover:shadow transition">
                        <div class="text-sm text-gray-700 font-semibold">
                            <?php echo e($answer->user->name ?? 'Anònim'); ?>

                            <span class="text-gray-400">·</span>
                            <?php if (isset($component)) { $__componentOriginale3e28e04f919b6b669f6ec61c6c79956 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3e28e04f919b6b669f6ec61c6c79956 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.solution-badge','data' => ['noSolution' => $answer->no_solution,'solution' => $answer->solution]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('solution-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['no-solution' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($answer->no_solution),'solution' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($answer->solution)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3e28e04f919b6b669f6ec61c6c79956)): ?>
<?php $attributes = $__attributesOriginale3e28e04f919b6b669f6ec61c6c79956; ?>
<?php unset($__attributesOriginale3e28e04f919b6b669f6ec61c6c79956); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3e28e04f919b6b669f6ec61c6c79956)): ?>
<?php $component = $__componentOriginale3e28e04f919b6b669f6ec61c6c79956; ?>
<?php unset($__componentOriginale3e28e04f919b6b669f6ec61c6c79956); ?>
<?php endif; ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">
                            <?php
                                $snippet = '';
                                if ($answer->format === 'text') {
                                    $snippet = \Illuminate\Support\Str::limit((string) $answer->content_text, 120);
                                } elseif ($answer->format === 'video') {
                                    $snippet = 'Vídeo: '.$answer->video_url;
                                } elseif ($answer->format === 'image') {
                                    $snippet = 'Resposta en imatge';
                                }
                            ?>
                            <?php echo e($snippet); ?>

                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500"><?php echo e(__('Encara no hi ha respostes.')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/Tom/PhpstormProjects/web-copa-canguro/resources/views/questions/show.blade.php ENDPATH**/ ?>